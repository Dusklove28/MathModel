2026 华为杯 A 题可运行程序（题号 A，队号 26106560013）

环境：Python 3.10 或更新版本。求解器与官方评估器只依赖 Python 标准库。
本包包含题目给定的 100 个 case、原版 config.txt、原版评估器、三问求解程序、
固定划分文件及逐例官方结果 CSV；不包含原机器的绝对路径缓存和数 GB 的历史计划。
请先解压到一个空目录，在该目录下执行。所有输出请写入新的 out/ 目录。

快速接口与单例试跑（通常远低于全量时间）：
  python run_problem1_full.py --help
  python run_problem2_baseline.py --help
  python run_problem3_g1.py --help
  python -u run_problem2_baseline.py --repo . --output out/p2_smoke --cache out/p2_cache --cases case_001 --max-cores 1 --workers 1

全量复现的依赖顺序（建议服务器执行；每条均可能超过 20 分钟）：
  python -u run_problem1_full.py --data-dir data --config data/config.txt --output-root out/p1_full --candidate-output-root out/p1_candidates --cache-dir out/p1_cache --workers 8 --allow-missing-development-manifests
  python -u run_problem1_inherited_fallback.py --data-dir data --config data/config.txt --full-root out/p1_full --candidate-output-root out/p1_candidates --cache-dir out/p1_cache --output-root out/p1_inherited --workers 8
  python -u run_problem2_baseline.py --repo . --output out/p2_base --cache out/p2_cache --workers 8
  python -u run_problem2_final.py --repo . --baseline out/p2_base --output out/p2_final --cache out/p2_final_cache --phase all --workers 8
  python -u run_problem3_g1.py --repo . --baseline out/p2_base --output out/p3_g1
  python -u run_problem3_g2.py --repo . --g1 out/p3_g1 --baseline out/p2_base --output out/p3_order --cache out/p3_order_cache --phase smoke
  将上一命令的 --phase 依次改为 development、validation、holdout 续跑同一输出目录。
  python -u probe_problem3_mapping.py --repo . --g2 out/p3_order --g1 out/p3_g1 --output out/p3_mapping --cache out/p3_mapping_cache --phase smoke
  同样按 development、validation、holdout 续跑映射分支，再运行：
  python -u report_problem3.py --repo . --g1 out/p3_g1 --g2 out/p3_mapping --g2-source out/p3_order --stage1 out/p2_base --mode g2 --output out/p3_report
  先查看各入口 --help 与冻结的分层文件。Q2/Q3 校验上游方案、配置、实现及
  官方评估器哈希；另一版本的历史缓存不能直接续跑。全量复算需要足够磁盘空间。

本包中的 team-authored Python 文件头增加 AI 使用注释，源码逻辑不变。
code/ 下题目原版评估器及其依赖按原始字节打包，绝未添加披露注释或修改。
manifest.json 记录每个文件的原始和打包后 SHA-256；检查程序可复核。
逐例表是已有官方实验结果的电子备查资料，重新运行会产生新的记录。

注意：官方上传手册要求附件名为 A26106560013.rar 且大小不超过 50 MB。
当前文件是用于检验和交接的 ZIP；需由参赛队用 RAR 工具转换、解压复核后上传。
最终参赛论文 PDF 应匿名，不能把本 README 中的队号写入论文正文。
